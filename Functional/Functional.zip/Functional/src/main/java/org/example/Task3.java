package org.example;

public class Task3 {
    
}
