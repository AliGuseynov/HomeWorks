package com.company;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

    public static void main(String[] args) {
	    Scanner myObj = new Scanner(System.in);
        System.out.println("Enter text: ");
        String text = myObj.nextLine();
        char [] symbols = text.toCharArray();


        System.out.println("Letters: ");
        for(char c:symbols){
            String temp = Character.toString(c);
            if(Pattern.matches("[a-zA-Z]",temp))
            {
                System.out.print(c + " ");
            }
        }
        System.out.println("\nNumbers: ");
        for(char c:symbols){
            String temp = Character.toString(c);
            if(Pattern.matches("[0-9]",temp))
            {
                System.out.print(c + " ");
            }
        }
    }
}
