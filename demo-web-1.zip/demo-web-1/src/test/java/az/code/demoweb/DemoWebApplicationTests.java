package az.code.demoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
