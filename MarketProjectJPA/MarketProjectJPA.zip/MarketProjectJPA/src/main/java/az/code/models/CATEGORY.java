package az.code.models;

public enum CATEGORY {
    FOOD,
    ELECTRONIC
}
