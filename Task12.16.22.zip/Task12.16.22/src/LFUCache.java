import javax.sound.midi.Soundbank;
import java.net.SocketImpl;

public class LFUCache<T> {
    private static int capacity;
    //private static int counterObj = 0;

    public static void setCapacity(int capacity) {
        LFUCache.capacity = capacity;
    }

    public static int getCapacity() {
        return capacity;
    }

    class Node<T>{
        T obj;
        Node<T> next;
        int frequency = 0;

        public Node(T obj){
            this.obj = obj;
            this.next = null;
        }

    }

    private Node head = null;
    private Node tail = null;

    //add method
    public void add(T obj){

        Node<T> newNode = new Node<T>(obj);

        int counterObj = count();
        if(head==null){
            head = newNode;
            tail = newNode;
        }
        else if(capacity == counterObj){
            int index = lfu();
            remove(index);
            tail.next = newNode;
            tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }

        //counterObj++;
    }

    //display all method
    public void display(){
        Node current = head;

        if(head == null) System.out.println("Empty List");
        else {
            while (current != null){
                System.out.println(current.obj + " ");
                current = current.next;
            }
        }

    }

    //get by index
    public Node get(int index){
        Node current = head;
        int counter = 0;

        while ((counter != index) && current != null){
            current = current.next;
            counter ++;
        }

        if(current != null) {
            current.frequency++;
            //System.out.println("frequency: " + current.frequency);
            return current;
        }
        else return null;
    }

    public void find(T obj){
        Node current = head;
        int index = 0;
        boolean found = false;

        while(current != null){
            if(current.obj.equals(obj)) {
                System.out.println(index);
                found = true;
            }
            current = current.next;
            index ++;
        }
        if (!found) System.out.println("Not found");

    }

    public void remove(int index){
        if(get(index) == null) {
            System.out.println("NA");
            return;
        }
        else {
            Node previousNode = head;

            if(previousNode.equals(get(index))){
                head = get(index).next;
                return;
            }

            while (!previousNode.next.equals(get(index))){
                previousNode = previousNode.next;
            }
            previousNode.next = get(index).next;

        }
    }

    //number of Nods
    public int count(){
        Node current = head;
        int count = 0;

        if(head == null) return count;
        else {
            while (current != null){
                current = current.next;
                count ++;
            }
        }
        return count;
    }

    //fount least frequently used
    public int lfu(){
        Node current = head;
        int min = head.frequency;
        int count = 0;
        int index = 0;

        if(head == null) return index;
        else {
            while (current != null){
                if(min >= current.frequency){
                    min = current.frequency;
                    index = count;
                }
                current = current.next;
                count++;
            }
        }
        return index;

    }

    public static void main(String[] args) {
        setCapacity(5);
        LFUCache<String> testFrequency = new LFUCache<String>();

        testFrequency.add("a");
        testFrequency.add("b");
        testFrequency.add("c");
        testFrequency.add("d");
        testFrequency.add("e");
        testFrequency.display();
        System.out.println(testFrequency.count());
        System.out.println("----");

        testFrequency.get(0);
        testFrequency.get(1);
        testFrequency.get(0);
        testFrequency.get(1);
        testFrequency.get(2);
        testFrequency.get(1);
        testFrequency.get(4);

        System.out.println(testFrequency.lfu());

        //testFrequency.remove(3);
        //testFrequency.display();
        System.out.println("----");
        testFrequency.add("fly");
        testFrequency.add("get");

        testFrequency.display();

        System.out.println(testFrequency.count());


    }

}


