import javax.sound.midi.Soundbank;
import java.net.SocketImpl;

public class MyLinkedList<T> {
    class Node<T>{
        T obj;
        Node<T> next;

        public Node(T obj){
            this.obj = obj;
            this.next = null;
        }
    }

    private Node head = null;
    private Node tail = null;

    //add method
    public void add(T obj){
        Node<T> newNode = new Node<T>(obj);

        if(head==null){
            head = newNode;
            tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }
    }

    //display all method
    public void display(){
        Node current = head;

        if(head == null) System.out.println("Empty List");
        else {
            while (current != null){
                System.out.println(current.obj + " ");
                current = current.next;
            }
        }

    }

    //get by index
    public Node get(int index){
        Node current = head;
        int counter = 0;

        while ((counter != index) && current != null){
            current = current.next;
            counter ++;
        }

        if(current != null) return current;
        else return null;
    }

    public void find(T obj){
        Node current = head;
        int index = 0;
        boolean found = false;

        while(current != null){
            if(current.obj.equals(obj)) {
                System.out.println(index);
                found = true;
            }
            current = current.next;
            index ++;
        }
        if (!found) System.out.println("Not found");

    }

    public void remove(int index){
        if(get(index) == null) {
            System.out.println("NA");
            return;
        }
        else {
            Node previousNode = head;

            if(previousNode.equals(get(index))){
                head = get(index).next;
                return;
            }

            while (!previousNode.next.equals(get(index))){
                previousNode = previousNode.next;
            }
            previousNode.next = get(index).next;

        }
    }

    //number of Nods
    public int count(){
        Node current = head;
        int count = 0;

        if(head == null) return count;
        else {
            while (current != null){
                current = current.next;
                count ++;
            }
        }
        return count;
    }



    public static void main(String[] args) {
        MyLinkedList<String> testList = new MyLinkedList<String>();

        testList.add("Hello");
        testList.add("Hola");
        testList.add("Konnichiwa");
        testList.add("Annyong");
        testList.add("Salam");

        //testList.display();
        //String x =  testList.get(3).obj;
        //System.out.println(testList.get(3).obj);
        //testList.find("Hola");
        testList.display();
        System.out.println(testList.count());
        testList.remove(2);
        System.out.println("---");
        testList.display();
        System.out.println(testList.count());

    }
}
