import javax.sound.midi.Soundbank;
import java.net.SocketImpl;

public class LRUCache<T> {
    private static int capacity;
    private static int counter = 0;

    public static void setCapacity(int capacity) {
        LRUCache.capacity = capacity;
    }

    public static int getCapacity() {
        return capacity;
    }

    class Element<T>{
        T obj;
        Element<T> next;

        public Element(T obj){
            this.obj = obj;
            this.next = null;
        }
    }

    private Element head = null;
    private Element tail = null;

    //add method
    public void add(T obj){
        Element<T> newElement = new Element<T>(obj);

        if(capacity < counter) {
            head.obj = newElement.obj;
        }
        else if(head==null){
            head = newElement;
            tail = newElement;
        }
        else{
            tail.next = newElement;
            tail = newElement;
        }
        counter++;
    }

    //display all method
    public void display(){
        Element current = head;

        if(head == null) System.out.println("Empty List");
        else {
            while (current != null){
                System.out.println(current.obj + " ");
                current = current.next;
            }
        }

    }

    //get by index
    private Element get(int index){


        Element current = head;
        int counter = 0;

        while ((counter != index) && current != null){
            current = current.next;
            counter ++;
        }


        if(current != null) {

            return current;
        }
        else return null;


    }

    public void getVer2(int index){

        moveToEnd(index);

        System.out.println(tail.obj);


    }


    public void find(T obj){
        Element current = head;
        int index = 0;
        boolean found = false;

        while(current != null){
            if(current.obj.equals(obj)) {
                System.out.println(index);
                found = true;
            }
            current = current.next;
            index ++;
        }
        if (!found) System.out.println("Not found");

    }

    public void remove(int index){
        if(get(index) == null) {
            System.out.println("NA");
            return;
        }
        else {
            Element previousNode = head;

            if(previousNode.equals(get(index))){
                head = get(index).next;
                return;
            }

            while (!previousNode.next.equals(get(index))){
                previousNode = previousNode.next;
            }
            previousNode.next = get(index).next;

        }
    }

    public void moveToEnd(int index){

        if(get(index) == null){
            return;
        }
        else{
            Element temp = get(index);
            remove(index);
            add((T) temp.obj);
        }

//        Element current = head;
//        int counter = 0;
//
//        while ((counter != index) && current != null){
//            current = current.next;
//            counter ++;
//        }
//
//
//        if(current != null) {
//            Element temp = current;
//            add((T) temp.obj);
//            remove(index);
//        }
//        else return;

    }

    //number of Nods
    public int count(){
        Element current = head;
        int count = 0;

        if(head == null) return count;
        else {
            while (current != null){
                current = current.next;
                count ++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        setCapacity(5);
        LRUCache<String> testList = new LRUCache<String>();

        testList.add("Hello");
        testList.add("Hola");
        testList.add("Konnichiwa");
        testList.add("Annyong");
        testList.add("Salam");
        testList.display();
        System.out.println("---");

        testList.getVer2(2);
        System.out.println("---");
        //testList.getVer2(3);
        testList.display();
        System.out.println("---");

        testList.add("Aloha");
        testList.add("Nihyao");
        testList.display();
        System.out.println("---");

        //testList.getVer2(4);
        //testList.moveToEnd(2);
        //testList.display();
    }
}
