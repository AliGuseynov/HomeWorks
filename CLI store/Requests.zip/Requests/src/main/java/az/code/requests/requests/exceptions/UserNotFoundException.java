package az.code.requests.requests.exceptions;

public class UserNotFoundException extends Throwable{
}
