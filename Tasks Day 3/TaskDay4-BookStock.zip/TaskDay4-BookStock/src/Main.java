import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner inn = new Scanner(System.in);

        ArrayList<BookList> library = new ArrayList<>();

        for (int i = 1; i <= 10; i++)
        {
            library.add(new BookList("Book " + i, "Author " + i, "Company x", new BookInstance(getRandomInteger(1, 10), StockType.inStock), Store.AliAndNino, "28 May"));
        }

        int searchInstanse = inn.nextInt();

        for (BookList e: library)
        {
            if (searchInstanse == e.bookInstance.getSerialNumber()) System.out.println(e.details());
        }

        String searchAuthorPublisher = inn.nextLine();

        int counterAll = 0;
        int counterSold = 0;
        int counterInStock = 0;

        for (BookList e: library){
            if(e.getAuthor().contains(searchAuthorPublisher) || e.getPublisher().contains(searchAuthorPublisher))
            {
                //counterAll += e.bookInstance.getSerialNumber(); 0r calculate count
                counterAll++;
                if(e.bookInstance.getType() == StockType.sold) counterSold++;
                else counterInStock++;
                System.out.println(e.bookInstance.getSerialNumber() + " " + e.getBook() + " " + e.getAuthor());
            }
        }
        System.out.println("All: " + counterAll + ". Sold: " + counterSold + ". In stock: " + counterInStock);



    }
    public static int getRandomInteger(int maximum, int minimum)
    {
        return ((int) (Math.random()*(maximum - minimum))) + minimum;
    }

}
