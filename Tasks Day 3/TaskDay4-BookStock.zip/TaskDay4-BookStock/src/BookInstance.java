public class BookInstance {
    private int serialNumber;
    StockType type;
    //maybe we have to add count?

    public BookInstance(){}

    public BookInstance(int serialNumber, StockType type){
        this.serialNumber = serialNumber;
        this.type = type;
    }

    public void setSerialNumber(int serialNumber) {
        this.serialNumber = serialNumber;
    }

    public int getSerialNumber() {
        return serialNumber;
    }

    public void setType(StockType type) {
        this.type = type;
    }

    public StockType getType() {
        return type;
    }
}
