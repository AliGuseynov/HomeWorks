public enum StockType {
    inStock,
    sold;
}
