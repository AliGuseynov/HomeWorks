public enum Store {
    AliAndNino,
    Libraff,
    BookCenter,
    Ovod;
}
