import java.io.File;

public class Main {
    public static void main(String[] args) {
        //Task1
        Task1.run();

        //Task2 Unfinished
//        XMLtoJson.convert();

        //Task3
//        FileSystemSearch.search("Jamal");
        FileSystemSearch.run();
    }
}
