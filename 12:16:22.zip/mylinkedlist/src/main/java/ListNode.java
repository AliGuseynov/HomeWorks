public class ListNode {

    int value;
    ListNode next;

    public ListNode(){
        this.value = -1;
        this.next = null;
    }
    public ListNode(int value){
        this.value = value;
        this.next = null;
    }
}
