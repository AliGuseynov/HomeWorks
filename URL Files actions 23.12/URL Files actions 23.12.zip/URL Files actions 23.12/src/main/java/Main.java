import homework23_12.*;

import java.io.File;

public class Main {
    public static void main(String[] args) {


        //Task 1
        // Generate students files
//        Seeder.generateStudentFiles();

//        StudentsDecoders.run();



        // Task 2
            WebsiteParserV2.parseURL("https://code.edu.az/", 0);



        // Task 4

//        int [] arr = Merge.merge(new int[]{1,2,3,0,0,0},3, new int[]{2,5,6},3);
//
//        for (int element: arr){
//            System.out.println(element);
//        }





//        //Task1
//        Task1.run();
//
//        //Task2 Unfinished
////        XMLtoJson.convert();
//
//        //Task3
////        FileSystemSearch.search("Jamal");
//        FileSystemSearch.run();
    }
}
