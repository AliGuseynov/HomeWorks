package Model;

import java.util.ArrayList;
import java.util.List;

public interface Employee {
    int getMonthSalary();
    void onFire();
    void onHire();
}
