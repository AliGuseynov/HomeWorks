import models.FileReader;

/**
 * Hello world!
 *
 */
public class Main
{
    public static void main( String[] args )
    {
        FileReader.readFile("files\\data.txt");
    }
}
