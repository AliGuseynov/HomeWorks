package Model;

import java.util.List;

public class Store {
    String name;
    String countryOfOrigins;


    public Store(String name, String countryOfOrigins) {
        this.name = name;
        this.countryOfOrigins = countryOfOrigins;
    }
}
